{
    "name": "Event Replenishment",
    "summary": "Aggregate yesterday's sales by brand for event replenishment",
    "version": "14.0.1.0.0",
    "author": "ChatGPT",
    "license": "LGPL-3",
    "depends": ["base", "point_of_sale", "sale"],
    "data": [
        "security/ir.model.access.csv",
        "views/event_replenishment_views.xml",
        "views/menu.xml",
        "data/cron.xml"
    ],
    "application": False,
    "installable": True
}