# -*- coding: utf-8 -*-
from odoo import api, fields, models
from datetime import date, timedelta

class EventReplenishmentWizard(models.TransientModel):
    _name = "event.replenishment.wizard"
    _description = "Compute yesterday sales by brand"

    date_from = fields.Date(default=lambda self: (date.today() - timedelta(days=1)))
    date_to = fields.Date(default=lambda self: (date.today() - timedelta(days=1)))
    source = fields.Selection([('pos','POS'), ('sale','Sales'), ('both','Both')], default='pos', required=True)

    def action_compute(self):
        self.ensure_one()
        return self.env['event.replenishment.brand.day'].run_compute(
            date_from=self.date_from, date_to=self.date_to, source=self.source
        )