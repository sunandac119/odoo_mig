# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from datetime import datetime, time, timedelta
import pytz

def _local_yesterday_bounds(env, date_from=False, date_to=False):
    # Return UTC datetimes for yesterday (00:00:00 to 23:59:59) in the user's timezone,
    # unless explicit date_from/date_to are given (naive date objects in user's tz).
    user_tz = env.user.tz or 'UTC'
    tz = pytz.timezone(user_tz)
    today_local = datetime.now(tz).date()
    if not date_from and not date_to:
        y = today_local - timedelta(days=1)
        start_local = tz.localize(datetime.combine(y, time(0,0,0)))
        end_local = tz.localize(datetime.combine(y, time(23,59,59)))
    else:
        start_local = tz.localize(datetime.combine(date_from, time(0,0,0)))
        end_local = tz.localize(datetime.combine(date_to, time(23,59,59)))
    return start_local.astimezone(pytz.UTC), end_local.astimezone(pytz.UTC)

class EventReplenishmentBrandDay(models.Model):
    _name = "event.replenishment.brand.day"
    _description = "Event Replenishment - Yesterday Sales by Brand"
    _order = "compute_date desc, brand_name asc"

    compute_date = fields.Date(required=True, index=True)
    source = fields.Selection([('pos','POS'), ('sale','Sales'), ('both','Both')], default='pos', required=True)
    brand_name = fields.Char(required=True, index=True)
    total_qty = fields.Float(digits=(16,2))
    total_amount = fields.Monetary(currency_field='currency_id')
    currency_id = fields.Many2one('res.currency', required=True, default=lambda self: self.env.company.currency_id.id)

    _sql_constraints = [
        ('date_brand_source_unique', 'unique(compute_date, source, brand_name)',
         'One record per date, source, and brand is allowed.')
    ]

    @api.model
    def _get_brand_name_from_product(self, product):
        # Try common brand fields on product template; fallback to category or 'Unknown'.
        brand = ''
        tmpl = product.product_tmpl_id
        if hasattr(tmpl, 'product_brand_id') and getattr(tmpl, 'product_brand_id'):
            brand = tmpl.product_brand_id.name or ''
        if not brand and hasattr(tmpl, 'brand_id') and getattr(tmpl, 'brand_id'):
            brand = tmpl.brand_id.name or ''
        if not brand and hasattr(tmpl, 'x_brand_id') and getattr(tmpl, 'x_brand_id'):
            brand = tmpl.x_brand_id.name or ''
        if not brand and hasattr(tmpl, 'x_brand') and getattr(tmpl, 'x_brand'):
            brand = tmpl.x_brand
        if not brand and getattr(tmpl, 'categ_id'):
            brand = "[%s]" % (tmpl.categ_id.display_name,)
        return brand or _("Unknown")

    @api.model
    def _aggregate_pos(self, start_utc, end_utc):
        # Aggregate POS order lines between bounds by brand.
        PosLine = self.env['pos.order.line'].sudo()
        lines = PosLine.search([
            ('order_id.date_order', '>=', start_utc.strftime('%Y-%m-%d %H:%M:%S')),
            ('order_id.date_order', '<=', end_utc.strftime('%Y-%m-%d %H:%M:%S')),
            ('order_id.state', 'in', ['paid', 'invoiced', 'done']),
        ])
        total_by_brand = {}
        for line in lines:
            brand_name = self._get_brand_name_from_product(line.product_id)
            data = total_by_brand.setdefault(brand_name, {'qty': 0.0, 'amt': 0.0})
            data['qty'] += line.qty or 0.0
            amt = getattr(line, 'price_subtotal_incl', None)
            if amt is None:
                amt = line.price_subtotal
            data['amt'] += amt or 0.0
        return total_by_brand

    @api.model
    def _aggregate_sale(self, start_utc, end_utc):
        # Aggregate Sales Order lines between bounds by brand (confirmed orders).
        SOL = self.env['sale.order.line'].sudo()
        lines = SOL.search([
            ('order_id.confirmation_date', '>=', start_utc.strftime('%Y-%m-%d %H:%M:%S')),
            ('order_id.confirmation_date', '<=', end_utc.strftime('%Y-%m-%d %H:%M:%S')),
            ('state', 'in', ['sale', 'done']),
        ])
        total_by_brand = {}
        for line in lines:
            brand_name = self._get_brand_name_from_product(line.product_id)
            data = total_by_brand.setdefault(brand_name, {'qty': 0.0, 'amt': 0.0})
            data['qty'] += line.product_uom_qty or 0.0
            amt = getattr(line, 'price_total', None)
            if amt is None:
                amt = (line.price_unit * line.product_uom_qty) - (line.discount or 0.0)
            data['amt'] += amt or 0.0
        return total_by_brand

    @api.model
    def run_compute(self, date_from=False, date_to=False, source='pos'):
        # Main entry: compute and upsert records for brand totals. Defaults to yesterday in user's TZ.
        start_utc, end_utc = _local_yesterday_bounds(self.env, date_from=date_from, date_to=date_to)
        compute_date = start_utc.date()
        currency = self.env.company.currency_id

        aggregates = {}
        if source in ('pos', 'both'):
            for b, d in self._aggregate_pos(start_utc, end_utc).items():
                agg = aggregates.setdefault(b, {'qty': 0.0, 'amt': 0.0})
                agg['qty'] += d['qty']
                agg['amt'] += d['amt']
        if source in ('sale', 'both'):
            for b, d in self._aggregate_sale(start_utc, end_utc).items():
                agg = aggregates.setdefault(b, {'qty': 0.0, 'amt': 0.0})
                agg['qty'] += d['qty']
                agg['amt'] += d['amt']

        for brand_name, vals in aggregates.items():
            rec = self.search([('compute_date','=',compute_date),
                               ('source','=',source),
                               ('brand_name','=',brand_name)], limit=1)
            payload = {
                'compute_date': compute_date,
                'source': source,
                'brand_name': brand_name,
                'total_qty': vals['qty'],
                'total_amount': vals['amt'],
                'currency_id': currency.id,
            }
            if rec:
                rec.write(payload)
            else:
                self.create(payload)

        action = self.env.ref('event_replenishment.action_event_replenishment_brand_day').read()[0]
        action['domain'] = [('compute_date','=',compute_date), ('source','=',source)]
        return action